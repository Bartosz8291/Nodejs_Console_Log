def console.log(message):
    print(message)

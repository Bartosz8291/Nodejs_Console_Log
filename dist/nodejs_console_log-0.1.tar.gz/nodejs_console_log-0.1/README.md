# Nodejs-Console-Log

This is a simple Python package that makes the Node.js `console.log()` function.

## Installation

```bash
pip install Nodejs-Console-Log
